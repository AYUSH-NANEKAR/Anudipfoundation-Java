import dao.BugDAO;
import java.util.List;
import java.util.Scanner;
import model.Bug;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n=== 🐞 Bug Tracker Menu ===");
            System.out.println("1. Add a new bug");
            System.out.println("2. View all bugs");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Description: ");
                    String description = scanner.nextLine();
                    System.out.print("Severity (Low/Medium/High): ");
                    String severity = scanner.nextLine();
                    System.out.print("Status (Open/In Progress/Resolved/Closed): ");
                    String status = scanner.nextLine();
                    System.out.print("Assignee: ");
                    String assignee = scanner.nextLine();

                    Bug newBug = new Bug(title, description, severity, status, assignee);
                    BugDAO.insertBug(newBug);
                    break;

                case 2:
                    List<Bug> bugs = BugDAO.getAllBugs();
                    if (bugs.isEmpty()) {
                        System.out.println("No bugs found.");
                    } else {
                        System.out.println("\n📋 Bug List:");
                        for (Bug bug : bugs) {
                            System.out.println("Title: " + bug.getTitle());
                            System.out.println("Description: " + bug.getDescription());
                            System.out.println("Severity: " + bug.getSeverity());
                            System.out.println("Status: " + bug.getStatus());
                            System.out.println("Assignee: " + bug.getAssignee());
                            System.out.println("-------------------------------------");
                        }
                    }
                    break;

                case 3:
                    running = false;
                    System.out.println("👋 Exiting Bug Tracker. Goodbye!");
                    break;

                default:
                    System.out.println("❌ Invalid option. Try again.");
            }
        }

        scanner.close();
    }
}