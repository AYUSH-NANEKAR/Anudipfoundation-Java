package dao;

import model.Bug;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class BugDAO {

   
    public static void insertBug(Bug bug) {
        String sql = "INSERT INTO bugs (title, description, severity, status, assignee) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, bug.getTitle());
            stmt.setString(2, bug.getDescription());
            stmt.setString(3, bug.getSeverity());
            stmt.setString(4, bug.getStatus());
            stmt.setString(5, bug.getAssignee());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("✅ Bug inserted successfully!");
            }

        } catch (Exception e) {
            System.out.println("❌ Failed to insert bug: " + e.getMessage());
        }
    }

   
    public static List<Bug> getAllBugs() {
        List<Bug> bugs = new ArrayList<>();
        String sql = "SELECT * FROM bugs";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Bug bug = new Bug(
                    rs.getString("title"),
                    rs.getString("description"),
                    rs.getString("severity"),
                    rs.getString("status"),
                    rs.getString("assignee")
                );
                bugs.add(bug);
            }

        } catch (Exception e) {
            System.out.println("❌ Failed to retrieve bugs: " + e.getMessage());
        }

        return bugs;
    }
}