package model;

public class Bug {
    private String title;
    private String description;
    private String severity;
    private String status;
    private String assignee;

    public Bug(String title, String description, String severity, String status, String assignee) {
        this.title = title;
        this.description = description;
        this.severity = severity;
        this.status = status;
        this.assignee = assignee;
    }

    // Getters
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getSeverity() { return severity; }
    public String getStatus() { return status; }
    public String getAssignee() { return assignee; }
}